<!DOCTYPE html>
<html lang="en">

<head>
  <link rel="stylesheet" href="homepage.css">
  <title>Final Project</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.min.css">
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,400;9..40,700&display=swap" rel="stylesheet">

  <script src="https://unpkg.com/scrollreveal"></script>
  <script src="https://kit.fontawesome.com/c4254e24a8.js"></script>

  <style>
    /* CSS for the user profile section */
    #user-profile {
      position: fixed;
      top: 20px;
      right: 20px;
      background-color: #fff;
      padding: 20px;
      /* Increased padding for a larger size */
      border: 2px solid #ccc;
      /* Increased border width */
      border-radius: 15px;
      /* Rounded corners */
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
      /* Add a shadow effect */
    }
  </style>
</head>

<body>
  <section>
    <div class="header">
      <nav>
        <h2 class="logo">PlaceHolder</h2>
        <ul>
          <li><a href="home.php">Home</a></li>
          <li><a href="about.php">About</a></li>
          <li><a href="plan.php">Plan</a></li>
          <li><a href="blog.php">Blog</a></li>
          <li><a href="contact.php">Contact</a></li>

        </ul>
        <a href="login.php">
          <button class="nav-button">Log in</button>
        </a>
        <div id="user-profile">
          <a href="user_profile.php">
            <img src="profile_image.jpg" alt="Profile Image">
          </a>
        </div>


        <div class="sec-05">

      <i class="fa-solid fa-user" onclick="toggleMenu()"></i>
      <div class="sub-menu-wrap" id="subMenu">
        <div class="sub-Menu">

          <div class="profile-card">
           <img src="./images/profile.jpg">
           
            <div class="username">Hello</div>
            <div class="email">hello@example.com</div>
            <a href="username.html" class="profile-button">Change Username</a>
            <label for="input-file">Update Image</label>

            <input type="file" accept="image/jpeg , image/png, image/jpg" id="input-file">
            
            <a href="changepassword.html" class="password-button">Change Password</a>
            <a href="#" class="logout-button">Log Out</a>
        </div>
        </div>
      </div>
    </div>

      </nav>


      <div class="description">
        <h1>PlaceHolder</h1>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>

      </div>

    </div>
  </section>

  <section>
    <div id="section2">
      <div class="container reveal ">
        <h2>Your Title</h2><br><br>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        </p>
        <br><br>

        <button class="button button2">See More...</button>

      </div>
    </div>
  </section>

  <section>
    <div id="section3">
      <div class="container reveal ">
        <div class="card">
          <img src="./images/Gym.jpg" class="card-img">
          <div class="card-body">
            <h1 class="card-title">TEXT</h1>
            <p class="card-info">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud </p>

          </div>

        </div>
        <div class="card">
          <img src="./images/Gym.jpg" class="card-img">
          <div class="card-body">
            <h1 class="card-title">TEXT</h1>
            <p class="card-info">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud </p>

          </div>

        </div>
        <div class="card">
          <img src="./images/Gym.jpg" class="card-img">
          <div class="card-body">
            <h1 class="card-title">TEXT</h1>
            <p class="card-info">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud </p>

          </div>

        </div>


      </div>

    </div>

    <section class="sec-03">
      <button class="button">See More...</button>

    </section>


  </section>

  <section>
    <div id="section4">
      <div class="container">

        <div class="row">
          <div class="col">
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, . Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>

          </div>
          <div class="col">
            <h3>Office <div class="underline"><span></span></div>
            </h3>
            <p>blah Road</p>
            <p>blahblah,blah</p>
            <p>blahblahblah</p>
            <p class="email-id">blahblah@gmail.com</p>
            <h4>+95-1234567</h4>

          </div>
          <div class="col">
            <h3>Links <div class="underline"><span></span></div>
            </h3>
            <ul>
              <li><a href="">Home</a></li>
              <li><a href="">About</a></li>
              <li><a href="">Plans</a></li>
              <li><a href="">Blog</a></li>
              <li><a href="">Contact</a></li>
            </ul>
          </div>
          <div class="col">
            <h3>NewsLetter <div class="underline"><span></span></div>
            </h3>
            <?php include('newsletter.php'); ?>
            <form>
              <i class="far fa-envelope"></i>
              <input type="emial" placeholder="Enter your email address" required>
              <button type="submit"><i class="fas fa-arrow-right"></i></button>

            </form>
            <div class="social-icons">
              <i class="fab fa-facebook-f"></i>
              <i class="fa-brands fa-x-twitter"></i>
              <i class="fa-brands fa-instagram"></i>
            </div>
          </div>
        </div>

        <hr>
        <p class="copyright">PlaceHolder &copy; 2023 - All Rights Reserved</p>


      </div>
    </div>
  </section>



</body>


<script type="text/javascript">
  window.addEventListener('scroll', reveal);

  function reveal() {
    var reveals = document.querySelectorAll('.reveal');

    for (var i = 0; i < reveals.length; i++) {
      var windowheight = window.innerHeight;
      var revealtop = reveals[i].getBoundingClientRect().top;
      var revealpoint = 150;

      if (revealtop < windowheight - revealpoint) {
        reveals[i].classList.add('active');
      } else {
        reveals[i].classList.remove('active');
      }
    }
  }
</script>
<script>
  let subMenu=document.getElementById("subMenu");

  function toggleMenu(){
    subMenu.classList.toggle("openmenu");
  }
</script>

</body>

</html>